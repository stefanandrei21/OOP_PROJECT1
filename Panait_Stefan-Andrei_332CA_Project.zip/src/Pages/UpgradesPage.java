package Pages;

public final class UpgradesPage extends Page {
    public UpgradesPage(final String upgradesPage) {
        super(upgradesPage);
    }
}
