package Pages;



public final class RegisterPage extends Page {

    public RegisterPage(final String registerPage) {
        super("Pages.RegisterPage");
    }

}
