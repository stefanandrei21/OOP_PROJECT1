package Pages;

public final class HomePage extends Page {
    public HomePage() {
    }

    public HomePage(final String title) {
        super(title);
    }

}
